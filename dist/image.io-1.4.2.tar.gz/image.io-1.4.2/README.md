
# Image.IO (Alpha)               
 **image.io** is a package created to power the user with easy image manipulation like **Circular cropping**, **Merging two images**, **Adding text** etc.
    
 - **GitHub [Repo](https://github.com/jnsougata/Image.IO)**    
    
 - **Join [Discord](https://discord.gg/YAFGAaMrTC)**    

# Docs coming soon!